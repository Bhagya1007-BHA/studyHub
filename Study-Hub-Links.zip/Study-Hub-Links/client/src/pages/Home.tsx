import { useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Search, Calculator, Code2, ArrowRight, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Navbar } from "@/components/Navbar";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    window.location.href = `/resources?search=${encodeURIComponent(searchQuery)}`;
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative pt-20 pb-32 overflow-hidden">
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary/10 rounded-full blur-3xl opacity-50 translate-x-1/3 -translate-y-1/3" />
          <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-accent/10 rounded-full blur-3xl opacity-50 -translate-x-1/3 translate-y-1/3" />
        </div>

        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <span className="inline-flex items-center px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
              <Sparkles className="w-4 h-4 mr-2" />
              Your Ultimate Learning Companion
            </span>
            <h1 className="text-5xl md:text-7xl font-display font-bold mb-6 leading-tight">
              Master <span className="text-gradient">Math</span> & <span className="text-gradient">Code</span><br />
              All in One Place
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
              Curated collection of the best free websites, apps, and tools to help you ace your exams and build your future.
            </p>

            <form onSubmit={handleSearch} className="max-w-xl mx-auto mb-12 relative group">
              <div className="absolute inset-0 bg-gradient-to-r from-primary to-accent rounded-2xl blur opacity-20 group-hover:opacity-30 transition-opacity" />
              <div className="relative flex items-center bg-white rounded-2xl shadow-xl p-2">
                <Search className="ml-4 h-5 w-5 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="What do you want to learn today?"
                  className="border-0 shadow-none focus-visible:ring-0 text-lg py-6 bg-transparent"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <Button size="lg" className="rounded-xl px-8 font-semibold">
                  Search
                </Button>
              </div>
            </form>

            <div className="flex flex-wrap justify-center gap-6">
              <CategoryCard 
                title="Mathematics" 
                icon={<Calculator className="w-8 h-8 text-blue-600" />}
                description="Algebra, Calculus, Geometry & more"
                href="/resources?category=math"
                color="bg-blue-50 hover:bg-blue-100 border-blue-200"
              />
              <CategoryCard 
                title="Programming" 
                icon={<Code2 className="w-8 h-8 text-purple-600" />}
                description="Python, JS, Web Dev & Algorithms"
                href="/resources?category=coding"
                color="bg-purple-50 hover:bg-purple-100 border-purple-200"
              />
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features/Trust Section */}
      <section className="py-24 bg-white/50 border-t border-border/50">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <Feature 
              title="Curated Quality" 
              description="Only the highest rated and most effective learning tools make it to our list."
            />
            <Feature 
              title="Always Free" 
              description="Focus on free and open-source resources accessible to every student."
            />
            <Feature 
              title="Community Driven" 
              description="Regularly updated with new discoveries from students like you."
            />
          </div>
        </div>
      </section>
    </div>
  );
}

function CategoryCard({ title, icon, description, href, color }: any) {
  return (
    <Link href={href}>
      <div className={`cursor-pointer w-full md:w-80 p-6 rounded-2xl border ${color} transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg`}>
        <div className="flex items-center gap-4 mb-4">
          <div className="p-3 bg-white rounded-xl shadow-sm">
            {icon}
          </div>
          <h3 className="font-display font-bold text-xl">{title}</h3>
        </div>
        <p className="text-muted-foreground mb-4 text-left">{description}</p>
        <div className="flex items-center text-sm font-semibold text-slate-900 group">
          Explore Resources
          <ArrowRight className="ml-2 w-4 h-4 transition-transform group-hover:translate-x-1" />
        </div>
      </div>
    </Link>
  );
}

function Feature({ title, description }: { title: string, description: string }) {
  return (
    <div className="p-6">
      <h3 className="font-display font-bold text-xl mb-3">{title}</h3>
      <p className="text-muted-foreground">{description}</p>
    </div>
  );
}
